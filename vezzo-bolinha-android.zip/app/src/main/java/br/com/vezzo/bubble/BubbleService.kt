package br.com.vezzo.bubble

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.*
import android.view.*
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class BubbleService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var bubble: FrameLayout
    private lateinit var pinBadge: TextView
    private lateinit var panel: LinearLayout
    private lateinit var tvInfo: TextView
    private lateinit var tvPin: TextView
    private lateinit var tvTips: TextView
    private lateinit var btnEnd: Button
    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var running = true
    private var lastVolAt = -1L
    private var lastTipId = -1L
    private var panelOpen = false
    private lateinit var lp: WindowManager.LayoutParams

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cfg(k: String) = getSharedPreferences("cfg", MODE_PRIVATE).getString(k, "") ?: ""

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val ch = "vezzo"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(ch, "Vezzo Ride", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch).setContentTitle("Vezzo Ride ativo").setContentText("Bolinha flutuante ligada").setSmallIcon(R.drawable.ic_launcher).build()
        startForeground(1, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildBubble()
        thread { loop() }
    }

    private fun buildBubble() {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        lp = WindowManager.LayoutParams(-2, -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(180) }
        bubble = FrameLayout(this)
        val logo = ImageView(this).apply { setImageResource(R.drawable.logo); background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#07110c")); setStroke(dp(2), Color.parseColor("#4ff09a")) }; setPadding(dp(6), dp(6), dp(6), dp(6)) }
        bubble.addView(logo, FrameLayout.LayoutParams(dp(60), dp(60)))
        pinBadge = TextView(this).apply { text = ""; setTextColor(Color.parseColor("#04150d")); textSize = 11f; typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(dp(6), dp(1), dp(6), dp(1)); visibility = View.GONE
            background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(Color.parseColor("#4ff09a")) } }
        bubble.addView(pinBadge, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> { val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt(); if (Math.abs(dx) > 8 || Math.abs(dy) > 8) moved = true
                    lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(bubble, lp); if (panelOpen) placePanel() }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(bubble, lp)

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply { cornerRadius = dp(18).toFloat(); setColor(Color.parseColor("#0d1b14")); setStroke(dp(1), Color.parseColor("#1f3a2c")) } }
        tvInfo = TextView(this).apply { setTextColor(Color.parseColor("#a9c0b2")); textSize = 14f; text = "Aguardando passageiro" }
        tvPin = TextView(this).apply { setTextColor(Color.parseColor("#4ff09a")); textSize = 38f; typeface = android.graphics.Typeface.DEFAULT_BOLD; letterSpacing = 0.15f; text = "—" }
        tvTips = TextView(this).apply { setTextColor(Color.parseColor("#eef7f1")); textSize = 14f; text = "Gorjetas hoje: R$ 0,00" }
        btnEnd = Button(this).apply { text = "Encerrar sessão"; setTextColor(Color.parseColor("#ff6b6b")); setOnClickListener { endSession() } }
        listOf(tvInfo, tvPin, tvTips, btnEnd).forEach { panel.addView(it, LinearLayout.LayoutParams(-2, -2)) }
    }

    private val panelLp by lazy { WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START } }
    private fun placePanel() { panelLp.x = lp.x; panelLp.y = lp.y + dp(68); try { wm.updateViewLayout(panel, panelLp) } catch (_: Exception) {} }
    private fun togglePanel() {
        if (panelOpen) { wm.removeView(panel); panelOpen = false } else { placePanel(); wm.addView(panel, panelLp); panelOpen = true }
    }

    private var confirmEnd = false
    private fun endSession() {
        if (!confirmEnd) { confirmEnd = true; btnEnd.text = "Confirmar encerramento?"; ui.postDelayed({ confirmEnd = false; btnEnd.text = "Encerrar sessão" }, 3000); return }
        confirmEnd = false; btnEnd.text = "Encerrando…"
        thread { try { call("device-end", "POST") } catch (_: Exception) {}; ui.post { btnEnd.text = "Encerrar sessão"; Toast.makeText(this, "Sessão encerrada", Toast.LENGTH_SHORT).show() } }
    }

    private fun call(action: String, method: String = "GET"): JSONObject {
        val c = URL(cfg("url") + "/api/" + action).openConnection() as HttpURLConnection
        c.requestMethod = method; c.connectTimeout = 8000; c.readTimeout = 8000
        c.setRequestProperty("Authorization", "Bearer " + cfg("token"))
        if (method == "POST") { c.doOutput = true; c.outputStream.use { it.write(ByteArray(0)) } }
        val body = (if (c.responseCode in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        return JSONObject(body)
    }

    private fun loop() {
        while (running) {
            try { val j = call("device-state"); if (j.optBoolean("ok")) ui.post { render(j) } } catch (_: Exception) { ui.post { tvInfo.text = "Sem conexão com o servidor" } }
            Thread.sleep(3000)
        }
    }

    private fun render(j: JSONObject) {
        val pin = if (j.isNull("pin")) "" else j.optString("pin")
        val who = if (j.isNull("passenger")) "" else j.optString("passenger")
        tvInfo.text = if (j.optBoolean("active")) (if (who.isNotEmpty()) "$who na sessão" else "Sessão ativa") else if (j.optBoolean("pin_requested")) "Passageiro pediu acesso" else "Aguardando passageiro"
        tvPin.text = if (pin.isNotEmpty()) pin else "—"
        pinBadge.visibility = if (pin.isNotEmpty()) View.VISIBLE else View.GONE; pinBadge.text = pin
        tvTips.text = "Gorjetas hoje: R$ " + String.format(java.util.Locale("pt", "BR"), "%.2f", j.optLong("tips_today_cents") / 100.0)
        val lt = j.optJSONObject("last_tip")
        if (lt != null) { val id = lt.optLong("id"); if (lastTipId == -1L) lastTipId = id else if (id != lastTipId) { lastTipId = id
            Toast.makeText(this, "💚 Gorjeta recebida: R$ " + String.format(java.util.Locale("pt", "BR"), "%.2f", lt.optLong("amount_cents") / 100.0), Toast.LENGTH_LONG).show()
            (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(400, VibrationEffect.DEFAULT_AMPLITUDE)) } }
        val at = j.optLong("volume_target_at"); val target = j.optInt("volume_target", -1)
        if (lastVolAt == -1L) lastVolAt = at
        else if (at != lastVolAt && target in 0..100) { lastVolAt = at
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * target / 100f), 0) }
    }

    override fun onDestroy() {
        running = false
        try { wm.removeView(bubble) } catch (_: Exception) {}
        if (panelOpen) try { wm.removeView(panel) } catch (_: Exception) {}
        super.onDestroy()
    }
}
