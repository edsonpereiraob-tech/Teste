package br.com.vezzo.bubble

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val sp = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad * 2, pad, pad); gravity = Gravity.CENTER_HORIZONTAL }
        val logo = ImageView(this).apply { setImageResource(R.drawable.logo) }
        val url = EditText(this).apply { hint = "https://music.vezzoconnect.com.br"; setText(sp.getString("url", "https://music.vezzoconnect.com.br")); inputType = InputType.TYPE_TEXT_VARIATION_URI }
        val tok = EditText(this).apply { hint = "Token do app (painel do motorista)"; setText(sp.getString("token", "")) }
        fun save() { sp.edit().putString("url", url.text.toString().trim().trimEnd('/')).putString("token", tok.text.toString().trim()).apply() }
        val perm = Button(this).apply { text = "1. Permitir sobreposição"; setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } }
        val start = Button(this).apply { text = "2. Iniciar bolinha"; setOnClickListener {
            save()
            if (!Settings.canDrawOverlays(this@MainActivity)) { Toast.makeText(this@MainActivity, "Permita a sobreposição primeiro", Toast.LENGTH_LONG).show(); return@setOnClickListener }
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            startForegroundService(Intent(this@MainActivity, BubbleService::class.java))
            Toast.makeText(this@MainActivity, "Bolinha ativa", Toast.LENGTH_SHORT).show() } }
        val stop = Button(this).apply { text = "Parar bolinha"; setOnClickListener { stopService(Intent(this@MainActivity, BubbleService::class.java)) } }
        listOf(logo, url, tok, perm, start, stop).forEach { root.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
