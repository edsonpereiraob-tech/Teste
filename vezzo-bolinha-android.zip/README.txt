VEZZO BOLINHA (Android)
1) Abra esta pasta no Android Studio (Hedgehog ou mais novo). Ele baixa o Gradle sozinho.
2) Build > Build APK(s). O arquivo sai em app/build/outputs/apk/debug/app-debug.apk
3) Instale no celular do carro. Abra o app, cole o TOKEN (aparece no painel do motorista, em "Token do app"),
   toque em 1) Permitir sobreposição e 2) Iniciar bolinha.
Bolinha: arraste pra onde quiser. Toque pra abrir PIN, nome, gorjetas e Encerrar sessão (2 toques).
Volume: quando o Spotify não aceitar controle remoto de volume, o app ajusta o volume de mídia do próprio celular.

GERAR O APK PELO GITHUB (sem PC)
1) Crie conta em github.com e um repositorio PRIVADO (ex.: vezzo-bolinha).
2) Envie TODO o conteudo desta pasta (inclusive a pasta oculta .github). No site: Add file > Upload files.
3) Aba Actions > "Build APK" > Run workflow. Espere ~5 min.
4) Abra a execucao concluida, role ate "Artifacts" e baixe vezzo-bolinha-apk (zip com o app-debug.apk).
